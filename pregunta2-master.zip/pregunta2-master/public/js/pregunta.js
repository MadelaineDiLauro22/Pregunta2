$(document).ready(function() {
    var puntos = 0;

    $('#finPartida').modal({
        backdrop: 'static',
        keyboard: false
    });
});